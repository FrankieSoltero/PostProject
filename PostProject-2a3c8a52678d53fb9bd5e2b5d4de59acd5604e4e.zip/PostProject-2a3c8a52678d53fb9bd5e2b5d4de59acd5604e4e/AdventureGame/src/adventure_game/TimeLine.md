**TimeLine**

1. Create A JFrame but remove custom player and change it to Choose Player
2. Create a Save Function by saving room and player level
3. Create a new game load game quit game when character dies
4. Add another level by creating a nextlevel function
5. Once all of this is done, make it stay all in one window using JPanels
