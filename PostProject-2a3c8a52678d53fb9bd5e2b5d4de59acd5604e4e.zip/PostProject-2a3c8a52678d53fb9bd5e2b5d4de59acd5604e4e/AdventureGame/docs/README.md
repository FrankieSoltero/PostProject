Put your javadoc website in this directory.

