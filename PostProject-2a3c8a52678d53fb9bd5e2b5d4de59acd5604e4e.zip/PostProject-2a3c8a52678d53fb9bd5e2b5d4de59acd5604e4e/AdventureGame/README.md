# Custom Features
- I have edited the mana function to become a level up function that will allow for xp to be given after every fight
- When a character levels up health and damage increase by 10 percent.
- I added an easter egg that when a player is prompted to create their character and enter 420 as their health they get 4200 health and are allowed to allocate 20 points to damage.
- Every character starts at level 0
- Weapons allows for knives, pistols, shotguns, and machine guns to be created
- These weapons are not like a consumable they only affect how much damage a player does, they are leveled 0-5 and can be stacked upon eachother.
- There will only be about 5-10 weapons throughout the whole map
Document your custom features here:
Instead of doing spells and a mana function I am doing leveling, bandage creation, use of itmes while not in combat, and an easter egg which when input 420 for health a Joint is smoked and the characters health is set 4200. The NPCS spawn randomly through out the map and the Boss NPC and Cure are only in room 10.
# Acknowledgements

Thank you to Ted Holmberg for inspiration, ideas, and mechanics which have ended up in this project.
Thank you to my Computer Science teacher Arron Maus for providing the project, in which I have transformed into a Zombie adventure game.
